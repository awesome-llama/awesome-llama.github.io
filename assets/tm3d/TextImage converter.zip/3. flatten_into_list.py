# combine all files into a single one

import os

def list_files(directory):
    """Get a list of all file names in a directory"""
    files = []
    for f in os.listdir(directory):
        if os.path.isfile(os.path.join(directory, f)):
            files.append(f)
    return files

def flatten(directory, dest_file_name, separator='\n'):

    combined_file = []

    for file_name in list_files(directory):
        # ensure the file is an image
        root, ext = os.path.splitext(file_name)
        if ext != '.txt': continue
        if root == 'region_pod': continue

        print(file_name)
        
        with open(directory + file_name) as f:
            combined_file.append(root + separator)
            combined_file.append(f.read() + separator)
        #if file_name in []: img = img.convert('L') # RGB to L

    if not os.path.exists(directory+'combined/'):
        os.makedirs(directory+'combined/')

    with open(directory + f'combined/{dest_file_name}.txt', 'w') as f:
        f.writelines(combined_file)


# the newline version is for importing into Scratch directly as a list.

# fullres
tgt_path = 'C:/Users/Atlas/Documents/Scratch/The Mast/exported regions/modified/' + 'TextImage_fullres/'
flatten(tgt_path, dest_file_name='combined', separator=' ')
flatten(tgt_path, dest_file_name='combined_list', separator='\n')

# small
tgt_path = 'C:/Users/Atlas/Documents/Scratch/The Mast/exported regions/modified/' + 'TextImage_small/'
flatten(tgt_path, dest_file_name='combined', separator=' ')
flatten(tgt_path, dest_file_name='combined_list', separator='\n')


