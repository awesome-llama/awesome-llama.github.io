"""import json

string = '!"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'

with open('dump1.json', 'w') as f:
    json.dump([string], f)
"""


def str_chunks(string, chunk_length, fill_char='') -> list:
    """Split a string into a list of substrings of a given length."""
    chunks = []
    for start_index in range(0, len(string), chunk_length):
        chunks.append(string[start_index:start_index+chunk_length])

    if fill_char != '':
        final_string = chunks[-1]
        while len(final_string) < chunk_length:
            final_string = final_string + fill_char
        
        chunks[-1] = final_string[:chunk_length]

    return chunks

print(str_chunks('abcdefghijklmnopqrstuvwxyz', 5, '_x'))

