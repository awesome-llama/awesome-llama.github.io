import math

def col_to_bin(col):
    return f'{col[0]//8:05b}' + f'{col[1]//8:05b}' + f'{col[2]//16:04b}'


def bin_to_col(bin='00000000000000'):
    return (
        int(bin[0:5], 2) * 8,
        int(bin[5:10], 2) * 8,
        int(bin[10:14], 2) * 16
    )

def dec_to_col(dec):
    return bin_to_col(f'{dec:014b}')

if False:
    num = 12

    print(dec_to_col(num))
    print(f'{num:014b}')
    bin = f'{num:014b}'
    print(bin_to_col(bin))
    col = bin_to_col(bin)
    # reverse
    print()

    print(col_to_bin(col))

CHARS = ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'


chunk_numbers = [CHARS.index(char) for char in 'region']

# group into pixels
colours = []
for ci in range(0, len(chunk_numbers), 2):
    dec = chunk_numbers[ci]*128 + chunk_numbers[ci+1]
    colours.append(dec_to_col(dec))

print(colours)

for col in colours:
    print(col_to_bin(col))
    num = int(col_to_bin(col), 2)
    print(CHARS[num//128], CHARS[num%128])
