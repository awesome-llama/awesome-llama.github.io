# generate the scannable fullres images

import os
from PIL import Image
import numpy as np


def list_files(directory):
    """Get a list of all file names in a directory"""
    files = []
    for f in os.listdir(directory):
        if os.path.isfile(os.path.join(directory, f)):
            files.append(f)
    return files


def col_to_bin(col):
    return f'{col[0]//8:05b}' + f'{col[1]//8:05b}' + f'{col[2]//16:04b}'

def bin_to_col(bin='00000000000000'):
    return (
        int(bin[0:5], 2) * 8,
        int(bin[5:10], 2) * 8,
        int(bin[10:14], 2) * 16
    )

def dec_to_col(dec):
    return bin_to_col(f'{dec:014b}')

def str_chunks(string, chunk_length, fill_char='') -> list:
    """Split a string into a list of substrings of a given length."""
    chunks = []
    for start_index in range(0, len(string), chunk_length):
        chunks.append(string[start_index:start_index+chunk_length])

    if fill_char != '':
        final_string = chunks[-1]
        while len(final_string) < chunk_length:
            final_string = final_string + fill_char
        
        chunks[-1] = final_string[:chunk_length]

    return chunks

######################


def generate_scannable_image_set(string_data, save_directory):
    CHARS = ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'

    # GENERATE IMAGES
    scannable_width, scannable_height = 460, 340
    total_pixels = scannable_width * scannable_height

    chunks = str_chunks(string_data, total_pixels*2, '_') # multiply by 2 as 2 chars can fit in 1 pixel

    #with open('dump.txt', 'w') as f:
    #    f.writelines([l + '\n' for l in chunks])
    checksums = []
    print(len(chunks))
    
    for i, chunk in enumerate(chunks):
        print(i)

        # convert the chunk into numbers
        #chunk_numbers = [CHARS.index(char) for char in chunk]
        chunk_numbers = []
        for char in chunk:
            if char == '\n':
                raise Exception('newline')
            try:
                chunk_numbers.append(CHARS.index(char))
            except:
                print(f'failed:"{char}"')
                raise Exception('')

        # group into pixels
        scan_checksum = 0
        colours = []
        for ci in range(0, len(chunk_numbers), 2):
            dec = chunk_numbers[ci]*128 + chunk_numbers[ci+1]
            scan_checksum += dec
            colours.append(dec_to_col(dec))
        
        checksums.append(scan_checksum)

        # make the image
        arr = np.array(colours, np.uint8)
        newarr = np.flip(arr.reshape(scannable_height, scannable_width, 3), 0)

        im = Image.fromarray(obj=newarr, mode='RGB')
        im.save(f'{save_directory}data{i}.png')
    
    # save checksums
    with open(save_directory + 'checksums.txt', 'w') as f:
        f.writelines([str(l)+ '\n' for l in checksums])





################

DIRECTORY = 'C:/Users/Atlas/Documents/Scratch/The Mast/exported regions/modified/TextImage_fullres/combined/'


if not os.path.exists(DIRECTORY+'scannable/'):
    os.makedirs(DIRECTORY+'scannable/')

with open(DIRECTORY + 'combined.txt') as f:
    combined_file = f.read()
    combined_file = combined_file.replace('\n', ' ') # replace newlines with space

generate_scannable_image_set(combined_file, DIRECTORY+'scannable/')

