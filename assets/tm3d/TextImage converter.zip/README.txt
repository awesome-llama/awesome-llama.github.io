The files are provided as-is.
No support provided. You need to know Python to be able to use them. 

These files are what I (awesome-llama) use to set up the game.
Image format: https://github.com/awesome-llama/TextImage