# TextImage version
# convert all png files in the folder to TextImage

from PIL import Image
import os
import image_io

DIRECTORY = 'C:/Users/Atlas/Documents/Scratch/The Mast/exported regions/modified/'

def list_files(directory):
    """Get a list of all file names in a directory"""
    files = []
    for f in os.listdir(directory):
        if os.path.isfile(os.path.join(directory, f)):
            files.append(f)
    return files

DEBUG = False

if not os.path.exists(DIRECTORY+'TextImage_fullres/'):
    os.makedirs(DIRECTORY+'TextImage_fullres/')

for file_name in list_files(DIRECTORY):
    # ensure the file is an image
    root, ext = os.path.splitext(file_name)
    if ext != '.png': continue

    print(file_name)
    img = Image.open(DIRECTORY+file_name)
    
    #if file_name in []: img = img.convert('L') # RGB to L

    txtimg = image_io.load_from_pillow_image(img, debug=DEBUG)
    
    # no transparency needed
    if 'alpha' in txtimg.layers:
        txtimg.layers.pop('alpha')

    print(txtimg)

    txtimg.save(DIRECTORY+'TextImage_fullres/'+root+'.txt')
